package main;

import Menu.MenuPrincipal;


public class Proyecto { 
    public static void main(String[] args) {
        MenuPrincipal programa = new MenuPrincipal();
        programa.setVisible(true);  
        programa.setLocationRelativeTo(null);
    }   
}